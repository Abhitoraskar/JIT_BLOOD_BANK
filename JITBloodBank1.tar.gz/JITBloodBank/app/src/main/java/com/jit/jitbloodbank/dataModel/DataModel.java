package com.jit.jitbloodbank.dataModel;

/**
 * Created by Lenovo on 02/10/2017.
 */

public class DataModel {
    String userId,userName,userBloodGroup,userGender,userAddress,userContact;

    public DataModel(String userId, String userName, String userBloodGroup, String userGender, String userAddress, String userContact) {
        this.userId = userId;
        this.userName = userName;
        this.userBloodGroup = userBloodGroup;
        this.userGender = userGender;
        this.userAddress = userAddress;
        this.userContact = userContact;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserBloodGroup() {
        return userBloodGroup;
    }

    public void setUserBloodGroup(String userBloodGroup) {
        this.userBloodGroup = userBloodGroup;
    }

    public String getUserGender() {
        return userGender;
    }

    public void setUserGender(String userGender) {
        this.userGender = userGender;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserContact() {
        return userContact;
    }

    public void setUserContact(String userContact) {
        this.userContact = userContact;
    }
}
